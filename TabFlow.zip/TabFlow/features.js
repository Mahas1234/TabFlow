// TabFlow AI Features
export default class TabManager {
  constructor() {
    this.initializeStorage();
  }

  async initializeStorage() {
    try {
      const { settings } = await chrome.storage.local.get('settings');
      if (!settings) {
        await chrome.storage.local.set({
          settings: {
            autoGroup: true,
            groupByDomain: true,
            maxTabsPerWindow: 20,
            pinImportant: true,
            darkMode: false
          }
        });
      }
    } catch (error) {
      console.error('Error initializing storage:', error);
    }
  }

  async saveSession() {
    try {
      const tabs = await chrome.tabs.query({});
      const session = {
        id: Date.now(),
        name: `Session ${new Date().toLocaleString()}`,
        tabs: tabs.map(tab => ({
          url: tab.url,
          title: tab.title,
          pinned: tab.pinned,
          groupId: tab.groupId
        })),
        created: Date.now()
      };

      const { sessions = [] } = await chrome.storage.local.get('sessions');
      sessions.push(session);
      await chrome.storage.local.set({ sessions });

      return session;
    } catch (error) {
      console.error('Error saving session:', error);
      return null;
    }
  }

  async restoreSession(sessionId) {
    try {
      const { sessions = [] } = await chrome.storage.local.get('sessions');
      const session = sessions.find(s => s.id === sessionId);
      
      if (!session) {
        throw new Error('Session not found');
      }

      const window = await chrome.windows.create({});
      
      for (const tab of session.tabs) {
        const newTab = await chrome.tabs.create({
          windowId: window.id,
          url: tab.url,
          pinned: tab.pinned
        });

        if (tab.groupId !== -1) {
          await chrome.tabs.group({
            tabIds: [newTab.id],
            groupId: tab.groupId
          });
        }
      }

      return true;
    } catch (error) {
      console.error('Error restoring session:', error);
      return false;
    }
  }

  async getSessions() {
    try {
      const { sessions = [] } = await chrome.storage.local.get('sessions');
      return sessions;
    } catch (error) {
      console.error('Error getting sessions:', error);
      return [];
    }
  }

  async deleteSession(sessionId) {
    try {
      const { sessions = [] } = await chrome.storage.local.get('sessions');
      const updatedSessions = sessions.filter(s => s.id !== sessionId);
      await chrome.storage.local.set({ sessions: updatedSessions });
      return true;
    } catch (error) {
      console.error('Error deleting session:', error);
      return false;
    }
  }

  async getSettings() {
    try {
      const { settings } = await chrome.storage.local.get('settings');
      return settings;
    } catch (error) {
      console.error('Error getting settings:', error);
      return null;
    }
  }

  async updateSettings(newSettings) {
    try {
      const currentSettings = await this.getSettings();
      const settings = { ...currentSettings, ...newSettings };
      await chrome.storage.local.set({ settings });
      return true;
    } catch (error) {
      console.error('Error updating settings:', error);
      return false;
    }
  }

  async autoOrganizeTabs() {
    try {
      const settings = await this.getSettings();
      if (!settings.autoGroup) return;

      const tabs = await chrome.tabs.query({});
      const groups = {};

      // Group tabs by domain if enabled
      if (settings.groupByDomain) {
        for (const tab of tabs) {
          if (tab.pinned) continue;

          const domain = new URL(tab.url).hostname;
          if (!groups[domain]) {
            groups[domain] = [];
          }
          groups[domain].push(tab.id);
        }

        // Create groups for domains with multiple tabs
        for (const [domain, tabIds] of Object.entries(groups)) {
          if (tabIds.length > 1) {
            const groupId = await chrome.tabGroups.create({});
            await chrome.tabs.group({
              tabIds,
              groupId
            });
            await chrome.tabGroups.update(groupId, {
              title: domain,
              color: this.getGroupColor(domain)
            });
          }
        }
      }

      // Pin important tabs if enabled
      if (settings.pinImportant) {
        const importantDomains = [
          'mail.google.com',
          'calendar.google.com',
          'docs.google.com',
          'github.com'
        ];

        for (const tab of tabs) {
          const domain = new URL(tab.url).hostname;
          if (importantDomains.some(d => domain.includes(d))) {
            await chrome.tabs.update(tab.id, { pinned: true });
          }
        }
      }

      return true;
    } catch (error) {
      console.error('Error auto-organizing tabs:', error);
      return false;
    }
  }

  getGroupColor(domain) {
    const colors = [
      'grey',
      'blue',
      'red',
      'yellow',
      'green',
      'pink',
      'purple',
      'cyan'
    ];
    
    // Generate a consistent color based on the domain
    const hash = domain.split('').reduce((acc, char) => {
      return char.charCodeAt(0) + ((acc << 5) - acc);
    }, 0);

    return colors[Math.abs(hash) % colors.length];
  }

  async createGroup(name, color = 'blue') {
    try {
      const groupId = await chrome.tabGroups.create({});
      await chrome.tabGroups.update(groupId, { title: name, color });
      return groupId;
    } catch (error) {
      console.error('Error creating group:', error);
      return null;
    }
  }

  async addTabToGroup(tabId, groupId) {
    try {
      await chrome.tabs.group({
        tabIds: [tabId],
        groupId
      });
      return true;
    } catch (error) {
      console.error('Error adding tab to group:', error);
      return false;
    }
  }

  async removeTabFromGroup(tabId) {
    try {
      await chrome.tabs.ungroup(tabId);
      return true;
    } catch (error) {
      console.error('Error removing tab from group:', error);
      return false;
    }
  }
}
