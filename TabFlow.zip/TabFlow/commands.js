// Keyboard shortcuts and commands for TabFlow AI
export class CommandManager {
  constructor(tabManager) {
    this.tabManager = tabManager;
    this.setupCommands();
  }

  setupCommands() {
    // Command palette
    document.addEventListener('keydown', (e) => {
      // Quick search: Press '/'
      if (e.key === '/' && !e.target.matches('input, textarea')) {
        e.preventDefault();
        document.getElementById('searchInput').focus();
      }

      // Command palette: Ctrl/Cmd + K
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        this.showCommandPalette();
      }

      // Focus mode: Ctrl/Cmd + Shift + F
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'f') {
        e.preventDefault();
        this.tabManager.startFocusMode();
      }

      // Save session: Ctrl/Cmd + Shift + S
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 's') {
        e.preventDefault();
        this.tabManager.exportTabSession();
      }

      // Quick switch: Ctrl/Cmd + Shift + Q
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'q') {
        e.preventDefault();
        this.quickSwitchGroup();
      }
    });
  }

  showCommandPalette() {
    const commands = [
      { id: 'focus', name: 'Start Focus Mode', icon: '🎯' },
      { id: 'save', name: 'Save Session', icon: '💾' },
      { id: 'merge', name: 'Merge Similar Tabs', icon: '🔄' },
      { id: 'organize', name: 'Auto-organize Tabs', icon: '📑' },
      { id: 'clean', name: 'Clean Up Tabs', icon: '🧹' },
      { id: 'stats', name: 'Show Statistics', icon: '📊' },
      { id: 'export', name: 'Export Sessions', icon: '📤' },
      { id: 'import', name: 'Import Sessions', icon: '📥' },
      { id: 'settings', name: 'Open Settings', icon: '⚙️' }
    ];

    const palette = document.createElement('div');
    palette.className = 'command-palette';
    palette.innerHTML = `
      <div class="command-search">
        <input type="text" placeholder="Type a command..." autofocus>
      </div>
      <div class="command-list">
        ${commands.map(cmd => `
          <div class="command-item" data-id="${cmd.id}">
            <span class="command-icon">${cmd.icon}</span>
            <span class="command-name">${cmd.name}</span>
          </div>
        `).join('')}
      </div>
    `;

    document.body.appendChild(palette);

    const input = palette.querySelector('input');
    input.focus();

    input.addEventListener('input', () => {
      const query = input.value.toLowerCase();
      const items = palette.querySelectorAll('.command-item');
      
      items.forEach(item => {
        const name = item.querySelector('.command-name').textContent.toLowerCase();
        item.style.display = name.includes(query) ? 'flex' : 'none';
      });
    });

    palette.addEventListener('click', (e) => {
      const item = e.target.closest('.command-item');
      if (item) {
        this.executeCommand(item.dataset.id);
        palette.remove();
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        palette.remove();
      }
    }, { once: true });
  }

  async executeCommand(commandId) {
    switch (commandId) {
      case 'focus':
        await this.tabManager.startFocusMode();
        break;
      case 'save':
        await this.tabManager.exportTabSession();
        break;
      case 'merge':
        await this.mergeSimilarTabs();
        break;
      case 'organize':
        await this.autoOrganizeAllTabs();
        break;
      case 'clean':
        await this.cleanUpTabs();
        break;
      case 'stats':
        document.querySelector('.stats-panel').style.display = 'block';
        break;
      case 'export':
        await this.exportSessions();
        break;
      case 'import':
        await this.importSessions();
        break;
      case 'settings':
        document.getElementById('settingsModal').style.display = 'block';
        break;
    }
  }

  async mergeSimilarTabs() {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const groups = {};

    // Group tabs by domain
    tabs.forEach(tab => {
      const domain = new URL(tab.url).hostname;
      if (!groups[domain]) groups[domain] = [];
      groups[domain].push(tab);
    });

    // Find and merge similar tabs
    for (const domain of Object.keys(groups)) {
      if (groups[domain].length > 1) {
        const similarTabs = groups[domain]
          .map(tab => ({
            tab,
            similarities: groups[domain]
              .filter(t => t.id !== tab.id)
              .map(t => ({
                tab: t,
                score: this.tabManager.calculateSimilarity(tab.title, t.title)
              }))
              .filter(s => s.score > 0.5)
          }))
          .filter(item => item.similarities.length > 0);

        if (similarTabs.length > 0) {
          await this.createTabGroup(similarTabs.map(item => item.tab));
        }
      }
    }
  }

  async createTabGroup(tabs) {
    const groupId = await chrome.tabGroups.create({});
    await chrome.tabs.group({
      groupId,
      tabIds: tabs.map(tab => tab.id)
    });
    await chrome.tabGroups.update(groupId, {
      title: 'Similar Tabs',
      color: 'purple'
    });
  }

  async autoOrganizeAllTabs() {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    for (const tab of tabs) {
      await this.tabManager.autoOrganizeTab(tab);
    }
  }

  async cleanUpTabs() {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const duplicates = new Map();
    const toClose = [];

    // Find duplicate tabs
    tabs.forEach(tab => {
      const key = tab.url;
      if (duplicates.has(key)) {
        toClose.push(tab.id);
      } else {
        duplicates.set(key, tab.id);
      }
    });

    // Close duplicate tabs
    if (toClose.length > 0) {
      await chrome.tabs.remove(toClose);
    }
  }

  async exportSessions() {
    const { savedSessions } = await chrome.storage.local.get('savedSessions');
    if (!savedSessions) return;

    const blob = new Blob([JSON.stringify(savedSessions, null, 2)], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tabflow-sessions-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  async importSessions() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';

    input.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const sessions = JSON.parse(e.target.result);
          const { savedSessions = [] } = await chrome.storage.local.get('savedSessions');
          await chrome.storage.local.set({
            savedSessions: [...savedSessions, ...sessions]
          });
        } catch (error) {
          console.error('Error importing sessions:', error);
        }
      };
      reader.readAsText(file);
    });

    input.click();
  }

  async quickSwitchGroup() {
    const groups = await chrome.tabGroups.query({ windowId: chrome.windows.WINDOW_ID_CURRENT });
    if (groups.length === 0) return;

    let activeGroup = null;
    const activeTab = await chrome.tabs.query({ active: true, currentWindow: true });
    if (activeTab.length > 0) {
      const groupId = activeTab[0].groupId;
      activeGroup = groups.findIndex(g => g.id === groupId);
    }

    const nextGroupIndex = activeGroup === null || activeGroup === groups.length - 1 ? 0 : activeGroup + 1;
    const nextGroup = groups[nextGroupIndex];

    const tabs = await chrome.tabs.query({ groupId: nextGroup.id });
    if (tabs.length > 0) {
      await chrome.tabs.update(tabs[0].id, { active: true });
    }
  }
}

// Export the CommandManager class
export default CommandManager;
