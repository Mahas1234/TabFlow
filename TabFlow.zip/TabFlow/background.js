// Track tab interaction times and statistics
let tabInteractions = {};
let tabStats = {
  domainVisits: {},
  categoryUsage: {},
  totalTabsOpened: 0,
  productiveTime: 0,
  leisureTime: 0,
  lastUpdate: Date.now()
};

// Initialize and load saved stats
chrome.runtime.onInstalled.addListener(async () => {
  const saved = await chrome.storage.local.get('tabStats');
  if (saved.tabStats) {
    tabStats = saved.tabStats;
  }
});

// Initialize tab tracking with error handling
chrome.tabs.onCreated.addListener(async (tab) => {
  try {
    tabStats.totalTabsOpened++;
    await updateTabStats(tab);
    await saveTabStats();
  } catch (error) {
    console.error('Error in onCreated:', error);
  }
});

chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    tabInteractions[activeInfo.tabId] = Date.now();
    const tab = await chrome.tabs.get(activeInfo.tabId);
    await updateTabStats(tab);
  } catch (error) {
    console.error('Error in onActivated:', error);
  }
});

// Monitor tab updates with error handling
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  try {
    if (changeInfo.status === 'complete') {
      tabInteractions[tabId] = Date.now();
      await updateTabStats(tab);
    }
  } catch (error) {
    console.error('Error in onUpdated:', error);
  }
});

// Enhanced categorization with ML-like scoring and domain-specific rules
function categorizeTab(tab) {
  try {
    if (!tab.url) return 'other';
    
    const url = tab.url.toLowerCase();
    const title = tab.title.toLowerCase();
    const hostname = new URL(url).hostname;
    
    // Calculate scores for each category
    const scores = {
      work: calculateWorkScore(url, title, hostname),
      research: calculateResearchScore(url, title, hostname),
      social: calculateSocialScore(url, title, hostname),
      entertainment: calculateEntertainmentScore(url, title, hostname)
    };
    
    // Return category with highest score
    return Object.entries(scores).reduce((a, b) => b[1] > a[1] ? b : a)[0];
  } catch (error) {
    console.error('Error in categorizeTab:', error);
    return 'other';
  }
}

function calculateWorkScore(url, title, hostname) {
  try {
    let score = 0;
    
    const workDomains = {
      'github.com': 0.8,
      'gitlab.com': 0.8,
      'bitbucket.org': 0.8,
      'jira.com': 0.9,
      'confluence.com': 0.9,
      'docs.google.com': 0.7,
      'sheets.google.com': 0.7,
      'slack.com': 0.6,
      'trello.com': 0.7,
      'asana.com': 0.7,
      'notion.so': 0.7,
      'linear.app': 0.8,
      'figma.com': 0.8
    };

    Object.entries(workDomains).forEach(([domain, weight]) => {
      if (hostname.includes(domain)) {
        score += weight;
      }
    });

    const workKeywords = {
      'project': 0.4,
      'task': 0.4,
      'meeting': 0.5,
      'sprint': 0.6,
      'report': 0.4,
      'dashboard': 0.4,
      'analysis': 0.4,
      'review': 0.4,
      'pull request': 0.7,
      'pr review': 0.7,
      'code': 0.5,
      'dev': 0.5,
      'test': 0.5,
      'bug': 0.6,
      'issue': 0.5,
      'documentation': 0.6
    };

    Object.entries(workKeywords).forEach(([keyword, weight]) => {
      if (title.includes(keyword)) {
        score += weight;
      }
    });

    return score;
  } catch (error) {
    console.error('Error in calculateWorkScore:', error);
    return 0;
  }
}

function calculateResearchScore(url, title, hostname) {
  try {
    let score = 0;
    
    const researchDomains = {
      'scholar.google.com': 0.9,
      'arxiv.org': 0.9,
      'researchgate.net': 0.8,
      'academia.edu': 0.8,
      'sciencedirect.com': 0.9,
      'ieee.org': 0.8,
      'springer.com': 0.8,
      'nature.com': 0.8,
      'pubmed.ncbi.nlm.nih.gov': 0.9,
      'semanticscholar.org': 0.8
    };

    Object.entries(researchDomains).forEach(([domain, weight]) => {
      if (hostname.includes(domain)) {
        score += weight;
      }
    });

    const researchKeywords = {
      'research': 0.5,
      'paper': 0.4,
      'study': 0.4,
      'analysis': 0.4,
      'journal': 0.6,
      'conference': 0.5,
      'proceedings': 0.6,
      'thesis': 0.7,
      'dissertation': 0.7,
      'methodology': 0.5,
      'experiment': 0.5,
      'theory': 0.4,
      'framework': 0.4
    };

    Object.entries(researchKeywords).forEach(([keyword, weight]) => {
      if (title.includes(keyword)) {
        score += weight;
      }
    });

    if (url.endsWith('.pdf') && (title.includes('paper') || title.includes('research') || title.includes('study'))) {
      score += 0.5;
    }

    return score;
  } catch (error) {
    console.error('Error in calculateResearchScore:', error);
    return 0;
  }
}

function calculateSocialScore(url, title, hostname) {
  try {
    let score = 0;
    
    const socialDomains = {
      'twitter.com': 0.8,
      'facebook.com': 0.8,
      'instagram.com': 0.8,
      'linkedin.com': 0.7,
      'reddit.com': 0.6,
      'discord.com': 0.7,
      'whatsapp.com': 0.8,
      'messenger.com': 0.8,
      'telegram.org': 0.8,
      'teams.microsoft.com': 0.6
    };

    Object.entries(socialDomains).forEach(([domain, weight]) => {
      if (hostname.includes(domain)) {
        score += weight;
      }
    });

    const socialKeywords = {
      'chat': 0.4,
      'message': 0.4,
      'social': 0.5,
      'friend': 0.4,
      'group': 0.3,
      'community': 0.4,
      'feed': 0.4,
      'profile': 0.3,
      'status': 0.3
    };

    Object.entries(socialKeywords).forEach(([keyword, weight]) => {
      if (title.includes(keyword)) {
        score += weight;
      }
    });

    return score;
  } catch (error) {
    console.error('Error in calculateSocialScore:', error);
    return 0;
  }
}

function calculateEntertainmentScore(url, title, hostname) {
  try {
    let score = 0;
    
    const entertainmentDomains = {
      'youtube.com': 0.8,
      'netflix.com': 0.9,
      'twitch.tv': 0.8,
      'spotify.com': 0.7,
      'soundcloud.com': 0.7,
      'vimeo.com': 0.7,
      'dailymotion.com': 0.7,
      'hulu.com': 0.9,
      'disneyplus.com': 0.9,
      'primevideo.com': 0.9,
      'hbomax.com': 0.9,
      'crunchyroll.com': 0.8,
      'steam.com': 0.8,
      'epicgames.com': 0.8
    };

    Object.entries(entertainmentDomains).forEach(([domain, weight]) => {
      if (hostname.includes(domain)) {
        score += weight;
      }
    });

    const entertainmentKeywords = {
      'video': 0.3,
      'watch': 0.3,
      'stream': 0.3,
      'movie': 0.5,
      'show': 0.3,
      'game': 0.4,
      'play': 0.3,
      'music': 0.4,
      'song': 0.4,
      'episode': 0.5,
      'season': 0.4,
      'trailer': 0.4,
      'funny': 0.3,
      'entertainment': 0.5
    };

    Object.entries(entertainmentKeywords).forEach(([keyword, weight]) => {
      if (title.includes(keyword)) {
        score += weight;
      }
    });

    return score;
  } catch (error) {
    console.error('Error in calculateEntertainmentScore:', error);
    return 0;
  }
}

async function updateTabStats(tab) {
  try {
    if (!tab.url) return;

    const domain = new URL(tab.url).hostname;
    const category = categorizeTab(tab);
    
    // Update domain visits
    tabStats.domainVisits[domain] = (tabStats.domainVisits[domain] || 0) + 1;
    
    // Update category usage
    tabStats.categoryUsage[category] = (tabStats.categoryUsage[category] || 0) + 1;
    
    // Update productive/leisure time
    const now = Date.now();
    const timeDiff = now - tabStats.lastUpdate;
    
    if (category === 'work' || category === 'research') {
      tabStats.productiveTime += timeDiff;
    } else if (category === 'entertainment' || category === 'social') {
      tabStats.leisureTime += timeDiff;
    }
    
    tabStats.lastUpdate = now;
    
    await saveTabStats();
  } catch (error) {
    console.error('Error in updateTabStats:', error);
  }
}

async function saveTabStats() {
  try {
    await chrome.storage.local.set({ tabStats });
  } catch (error) {
    console.error('Error saving tab stats:', error);
  }
}

// Handle messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  try {
    switch (request.action) {
      case 'getTabStats':
        sendResponse({ tabStats });
        break;
      case 'categorizeTab':
        sendResponse({ category: categorizeTab(request.tab) });
        break;
      case 'resetStats':
        tabStats = {
          domainVisits: {},
          categoryUsage: {},
          totalTabsOpened: 0,
          productiveTime: 0,
          leisureTime: 0,
          lastUpdate: Date.now()
        };
        saveTabStats();
        sendResponse({ success: true });
        break;
    }
  } catch (error) {
    console.error('Error in message handler:', error);
    sendResponse({ error: error.message });
  }
  return true;
});

// Check for inactive tabs every 30 minutes
setInterval(async () => {
  try {
    const tabs = await chrome.tabs.query({});
    const currentTime = Date.now();
    
    for (const tab of tabs) {
      const lastInteraction = tabInteractions[tab.id] || 0;
      const inactiveTime = currentTime - lastInteraction;
      
      // If tab has been inactive for more than 2 hours and is not important
      if (inactiveTime > 2 * 60 * 60 * 1000 && !isImportantTab(tab)) {
        chrome.tabs.sendMessage(tab.id, {
          action: 'suggestClose',
          inactiveTime: Math.round(inactiveTime / (60 * 1000)) // Convert to minutes
        });
      }
    }
  } catch (error) {
    console.error('Error checking inactive tabs:', error);
  }
}, 30 * 60 * 1000);

function isImportantTab(tab) {
  try {
    if (!tab.url) return false;
    
    // Don't close tabs with unsaved form data
    if (tab.hasForm) return true;
    
    const category = categorizeTab(tab);
    return category === 'work' || category === 'research';
  } catch (error) {
    console.error('Error in isImportantTab:', error);
    return false;
  }
}
