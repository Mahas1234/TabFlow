// TabFlow AI Popup UI
import TabManager from './features.js';

class TabFlowUI {
  constructor() {
    this.tabManager = new TabManager();
    this.searchDebounceTimer = null;
    this.initializeUI();
  }

  async initializeUI() {
    try {
      await this.setupEventListeners();
      await this.renderTabs();
      this.setupSearch();
      this.setupQuickActions();
      this.updateStats();
    } catch (error) {
      console.error('Error initializing UI:', error);
      this.showNotification('Error initializing UI', 'error');
    }
  }

  setupSearch() {
    const searchInput = document.getElementById('searchInput');
    const searchFilters = document.getElementById('searchFilters');

    searchInput.addEventListener('input', () => {
      clearTimeout(this.searchDebounceTimer);
      this.searchDebounceTimer = setTimeout(() => {
        this.performSearch(searchInput.value);
      }, 300);
    });

    searchFilters.addEventListener('click', (e) => {
      if (e.target.classList.contains('filter-btn')) {
        // Remove active class from all buttons
        searchFilters.querySelectorAll('.filter-btn').forEach(btn => {
          btn.classList.remove('active');
        });
        // Add active class to clicked button
        e.target.classList.add('active');
        // Perform search with new filter
        this.performSearch(searchInput.value);
      }
    });
  }

  async performSearch(query) {
    try {
      if (!query) {
        await this.renderTabs();
        return;
      }

      const tabs = await chrome.tabs.query({});
      const filter = document.querySelector('.filter-btn.active').dataset.filter;
      
      const filteredTabs = tabs.filter(tab => {
        switch (filter) {
          case 'title':
            return tab.title.toLowerCase().includes(query.toLowerCase());
          case 'url':
            return tab.url.toLowerCase().includes(query.toLowerCase());
          case 'content':
            // Content search requires additional permissions
            return false;
          default: // 'all'
            return tab.title.toLowerCase().includes(query.toLowerCase()) ||
                   tab.url.toLowerCase().includes(query.toLowerCase());
        }
      });

      await this.renderTabs(filteredTabs);
      this.highlightSearchResults(query);
    } catch (error) {
      console.error('Error performing search:', error);
      this.showNotification('Error performing search', 'error');
    }
  }

  highlightSearchResults(query) {
    if (!query) return;

    const tabElements = document.querySelectorAll('.tab-item');
    tabElements.forEach(tabElement => {
      const titleElement = tabElement.querySelector('.tab-title');
      const urlElement = tabElement.querySelector('.tab-url');

      if (titleElement) {
        titleElement.innerHTML = this.highlightText(titleElement.textContent, query);
      }
      if (urlElement) {
        urlElement.innerHTML = this.highlightText(urlElement.textContent, query);
      }
    });
  }

  highlightText(text, query) {
    const regex = new RegExp(`(${query})`, 'gi');
    return text.replace(regex, '<mark>$1</mark>');
  }

  setupQuickActions() {
    const sortTabsBtn = document.getElementById('sortTabs');
    const mergeWindowsBtn = document.getElementById('mergeWindows');
    const saveSessionBtn = document.getElementById('saveSession');

    sortTabsBtn.addEventListener('click', () => this.sortTabs());
    mergeWindowsBtn.addEventListener('click', () => this.mergeWindows());
    saveSessionBtn.addEventListener('click', () => this.saveSession());
  }

  async sortTabs() {
    try {
      const tabs = await chrome.tabs.query({ currentWindow: true });
      const sortedTabs = tabs.sort((a, b) => a.title.localeCompare(b.title));
      
      for (let i = 0; i < sortedTabs.length; i++) {
        await chrome.tabs.move(sortedTabs[i].id, { index: i });
      }
      
      await this.renderTabs();
      this.showNotification('Tabs sorted alphabetically', 'success');
    } catch (error) {
      console.error('Error sorting tabs:', error);
      this.showNotification('Error sorting tabs', 'error');
    }
  }

  async mergeWindows() {
    try {
      const windows = await chrome.windows.getAll({ populate: true });
      if (windows.length <= 1) {
        this.showNotification('No windows to merge', 'info');
        return;
      }

      const currentWindow = await chrome.windows.getCurrent();
      const otherWindows = windows.filter(w => w.id !== currentWindow.id);
      
      for (const window of otherWindows) {
        const tabs = window.tabs;
        if (tabs && tabs.length > 0) {
          await chrome.tabs.move(
            tabs.map(tab => tab.id),
            { windowId: currentWindow.id, index: -1 }
          );
        }
      }

      await this.renderTabs();
      this.showNotification('Windows merged successfully', 'success');
    } catch (error) {
      console.error('Error merging windows:', error);
      this.showNotification('Error merging windows', 'error');
    }
  }

  async saveSession() {
    try {
      const session = await this.tabManager.saveSession();
      if (session) {
        this.showNotification('Session saved successfully', 'success');
      } else {
        this.showNotification('Error saving session', 'error');
      }
    } catch (error) {
      console.error('Error saving session:', error);
      this.showNotification('Error saving session', 'error');
    }
  }

  async renderTabs(tabsToRender) {
    try {
      const tabContainer = document.getElementById('tabContainer');
      tabContainer.innerHTML = '';

      const tabs = tabsToRender || await chrome.tabs.query({});
      
      for (const tab of tabs) {
        const tabElement = this.createTabElement(tab);
        tabContainer.appendChild(tabElement);
      }

      this.updateStats();
    } catch (error) {
      console.error('Error rendering tabs:', error);
      this.showNotification('Error rendering tabs', 'error');
    }
  }

  createTabElement(tab) {
    const tabElement = document.createElement('div');
    tabElement.className = 'tab-item';
    tabElement.dataset.tabId = tab.id;

    const favicon = document.createElement('img');
    favicon.className = 'tab-favicon';
    favicon.src = tab.favIconUrl || 'icons/default-favicon.png';
    favicon.onerror = () => favicon.src = 'icons/default-favicon.png';

    const title = document.createElement('span');
    title.className = 'tab-title';
    title.textContent = tab.title;

    const url = document.createElement('span');
    url.className = 'tab-url';
    url.textContent = tab.url;

    const actions = document.createElement('div');
    actions.className = 'tab-actions';

    const closeBtn = document.createElement('button');
    closeBtn.className = 'tab-close';
    closeBtn.innerHTML = '×';
    closeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      this.closeTab(tab.id);
    });

    actions.appendChild(closeBtn);
    tabElement.append(favicon, title, url, actions);

    tabElement.addEventListener('click', () => this.activateTab(tab.id));
    tabElement.addEventListener('contextmenu', (e) => this.showContextMenu(e, tab));

    return tabElement;
  }

  async closeTab(tabId) {
    try {
      await chrome.tabs.remove(tabId);
      const tabElement = document.querySelector(`[data-tab-id="${tabId}"]`);
      if (tabElement) {
        tabElement.remove();
      }
      this.updateStats();
    } catch (error) {
      console.error('Error closing tab:', error);
      this.showNotification('Error closing tab', 'error');
    }
  }

  async activateTab(tabId) {
    try {
      await chrome.tabs.update(tabId, { active: true });
      window.close();
    } catch (error) {
      console.error('Error activating tab:', error);
      this.showNotification('Error activating tab', 'error');
    }
  }

  async updateStats() {
    try {
      const tabs = await chrome.tabs.query({});
      const windows = await chrome.windows.getAll();
      const groups = await chrome.tabGroups.query({});

      document.getElementById('totalTabs').textContent = tabs.length;
      document.getElementById('totalGroups').textContent = groups.length;
      document.getElementById('totalWindows').textContent = windows.length;
    } catch (error) {
      console.error('Error updating stats:', error);
    }
  }

  showNotification(message, type = 'info') {
    const notification = document.getElementById('notification');
    const messageElement = notification.querySelector('.notification-message');
    
    messageElement.textContent = message;
    notification.className = `notification ${type}`;
    notification.style.display = 'flex';

    setTimeout(() => {
      notification.style.display = 'none';
    }, 3000);
  }

  setupEventListeners() {
    // Close notification when clicking the close button
    const notificationClose = document.querySelector('.notification-close');
    if (notificationClose) {
      notificationClose.addEventListener('click', () => {
        document.getElementById('notification').style.display = 'none';
      });
    }

    // Handle keyboard shortcuts
    document.addEventListener('keydown', (e) => {
      // Close popup on Escape
      if (e.key === 'Escape') {
        window.close();
      }
      
      // Focus search on '/'
      if (e.key === '/' && !e.target.matches('input, textarea')) {
        e.preventDefault();
        document.getElementById('searchInput').focus();
      }
    });
  }
}

// Initialize the UI when the document is loaded
document.addEventListener('DOMContentLoaded', () => {
  new TabFlowUI();
});
